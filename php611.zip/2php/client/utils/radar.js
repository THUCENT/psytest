function draw(data) {
  console.log(data);
}

module.exports = {
  draw: draw
}
